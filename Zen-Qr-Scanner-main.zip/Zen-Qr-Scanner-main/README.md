# Zen-Qr-Scanner
Application pour Scanner des Qr code sécurisés par le protocole SSL pour se rediriger vers des plateformes web sécurisées.

(https![zen qr scan](https://user-images.githubusercontent.com/84296565/186545263-a2331e5d-d6d6-4415-8e90-afc2e53b62b9.png)
![part 1 qr scanner]://user-images.githubusercontent.com/84296565/186544553-2118264d-2652-40bf-aa66-1e77172c97e6.PNG)
![part 2 qr scanner](https://user-images.githubusercontent.com/84296565/186544564-2a3f348c-3906-4aef-bd12-40a4f9eb209d.PNG)
![part 3 qr scanner](https://user-images.githubusercontent.com/84296565/186544578-14c6fdee-183a-45c2-ac07-1ae398b19b70.PNG)
